#!/bin/bash

##KERNEL MODIFICADO

echo 'deb http://deb.xanmod.org releases main' | tee /etc/apt/sources.list.d/xanmod-kernel.list && wget -qO - https://dl.xanmod.org/gpg.key | apt-key add - && 

##ZRAMSWAP

apt update && apt install linux-xanmod -y && update-grub 
mkdir optimizacion && cd optimizacion && apt install git && git clone https://github.com/foundObjects/zram-swap.git && cd zram-swap && chmod +777 install.sh && ./install.sh 

##Stracer

apt install stacer -y

